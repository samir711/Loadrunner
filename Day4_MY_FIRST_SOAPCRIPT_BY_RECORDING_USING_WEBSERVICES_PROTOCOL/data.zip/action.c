Action()
{

	web_add_auto_header("User-Agent", "Java/1.8.0_152");

	return 0;
}