#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "as_web.h"
#include "lrw_custom_body.h"
#include "wssoap.h"
#include "SharedParameter.h"


//--------------------------------------------------------------------
// Global Variables

#endif // _GLOBALS_H
