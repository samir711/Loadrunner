Login()
{
	lr_output_message("Now we are in Login Action");
	return 0;
}
