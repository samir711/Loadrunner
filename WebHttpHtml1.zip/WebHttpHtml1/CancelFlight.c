CancelFlight()
{
	
	lr_output_message(" Now we are in cancel flight action ");
	return 0;
}
