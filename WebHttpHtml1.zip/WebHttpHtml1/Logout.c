Logout()
{
	lr_output_message("Now we are In the logout action");
	return 0;
}
