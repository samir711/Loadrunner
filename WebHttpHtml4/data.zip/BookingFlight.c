BookingFlight()
{

	/* *************ClickOnFlight***************** */

	lr_think_time(9);

	web_url("welcome.pl_2", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=search", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	/* **************FindFlight************* */

	lr_think_time(42);

	web_submit_form("reservations.pl", 
		"Snapshot=t15.inf", 
		ITEMDATA, 
		"Name=depart", "Value=Denver", ENDITEM, 
		"Name=departDate", "Value=11/25/2018", ENDITEM, 
		"Name=arrive", "Value=London", ENDITEM, 
		"Name=returnDate", "Value=11/26/2018", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=roundtrip", "Value=<OFF>", ENDITEM, 
		"Name=seatPref", "Value=None", ENDITEM, 
		"Name=seatType", "Value=Coach", ENDITEM, 
		LAST);

	/* *****************SelectFlight************ */

	lr_think_time(42);

	web_submit_form("reservations.pl_2", 
		"Snapshot=t16.inf", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=021;301;11/25/2018", ENDITEM, 
		"Name=reserveFlights.x", "Value=63", ENDITEM, 
		"Name=reserveFlights.y", "Value=6", ENDITEM, 
		LAST);

	/* *****************Payment************* */

	lr_think_time(7);

	web_submit_form("reservations.pl_3", 
		"Snapshot=t17.inf", 
		ITEMDATA, 
		"Name=firstName", "Value=samir", ENDITEM, 
		"Name=lastName", "Value=arora", ENDITEM, 
		"Name=address1", "Value=HIG 46 SECTOR A SONAGIRI RAISEN ROAD", ENDITEM, 
		"Name=address2", "Value=bhopal", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=creditCard", "Value=1234567890", ENDITEM, 
		"Name=expDate", "Value=1234", ENDITEM, 
		"Name=saveCC", "Value=<OFF>", ENDITEM, 
		LAST);

	return 0;
}
