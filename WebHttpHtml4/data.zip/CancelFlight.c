CancelFlight()
{

	/* ***********CancelFlight********** */

	lr_think_time(20);

	web_url("welcome.pl_3", 
		"URL=http://127.0.0.1:1080/cgi-bin/welcome.pl?page=itinerary", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://127.0.0.1:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t33.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(11);

	web_submit_form("itinerary.pl", 
		"Snapshot=t34.inf", 
		ITEMDATA, 
		"Name=1", "Value=on", ENDITEM, 
		"Name=2", "Value=<OFF>", ENDITEM, 
		"Name=3", "Value=<OFF>", ENDITEM, 
		LAST);

	return 0;
}